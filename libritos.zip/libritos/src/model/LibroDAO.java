package model;

import java.util.ArrayList;
import java.util.List;

public class LibroDAO {
    private List<Libro> listaLibros = new ArrayList<>();
    private int idContador = 1;

    public boolean insertar(Libro libro) {
        libro.setId(idContador++);
        return listaLibros.add(libro);
    }

    public List<Libro> listar() {
        return new ArrayList<>(listaLibros);
    }

    public boolean modificar(Libro libro) {
        for (int i = 0; i < listaLibros.size(); i++) {
            if (listaLibros.get(i).getId() == libro.getId()) {
                listaLibros.set(i, libro);
                return true;
            }
        }
        return false;
    }

    public boolean eliminar(int id) {
        return listaLibros.removeIf(libro -> libro.getId() == id);
    }
}