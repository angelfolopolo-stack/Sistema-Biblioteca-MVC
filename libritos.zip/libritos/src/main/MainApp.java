package main;

import controller.LibroController;
import model.LibroDAO;

public class MainApp {
    public static void main(String[] args) {
        // Inicializamos el modelo (capa de datos)
        LibroDAO modelo = new LibroDAO();
        
        // Inicializamos el controlador pasándole el modelo
        LibroController controlador = new LibroController(modelo);
        
        // Arrancamos el menú interactivo en la consola
        controlador.iniciarMenu();
    }
}