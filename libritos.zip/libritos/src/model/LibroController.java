package controller;

import java.util.List;
import java.util.Scanner;
import model.Libro;
import model.LibroDAO;

public class LibroController {
    private LibroDAO dao;
    private Scanner scanner;

    public LibroController(LibroDAO dao) {
        this.dao = dao;
        this.scanner = new Scanner(System.in);
    }

    public void iniciarMenu() {
        int opcion = 0;
        do {
            System.out.println("\n=== SISTEMA DE BIBLIOTECA (CRUD) ===");
            System.out.println("1. Registrar Libro");
            System.out.println("2. Listar Libros");
            System.out.println("3. Modificar Libro");
            System.out.println("4. Eliminar Libro");
            System.out.println("5. Salir");
            System.out.print("Seleccione una opcion: ");
            
            try {
                opcion = Integer.parseInt(scanner.nextLine());
                switch (opcion) {
                    case 1: registrar(); break;
                    case 2: listar(); break;
                    case 3: modificar(); break;
                    case 4: eliminar(); break;
                    case 5: System.out.println("Saliendo del sistema..."); break;
                    default: System.out.println("Opción no válida.");
                }
            } catch (NumberFormatException e) {
                System.out.println("Por favor, ingrese un número válido.");
            }
        } while (opcion != 5);
    }

    private void registrar() {
        System.out.println("\n--- REGISTRAR NUEVO LIBRO ---");
        Libro nuevo = new Libro();
        
        System.out.print("Título: ");
        nuevo.setTitulo(scanner.nextLine());
        System.out.print("Autor: ");
        nuevo.setAutor(scanner.nextLine());
        System.out.print("ISBN: ");
        nuevo.setIsbn(scanner.nextLine());
        
        dao.insertar(nuevo);
        System.out.println("¡Libro registrado con éxito!");
    }

    private void listar() {
        System.out.println("\n--- LISTA DE LIBROS ---");
        List<Libro> libros = dao.listar();
        if (libros.isEmpty()) {
            System.out.println("No hay libros registrados.");
            return;
        }
        System.out.printf("%-5s %-25s %-20s %-15s\n", "ID", "TITULO", "AUTOR", "ISBN");
        System.out.println("------------------------------------------------------------------");
        for (Libro l : libros) {
            System.out.printf("%-5d %-25s %-20s %-15s\n", l.getId(), l.getTitulo(), l.getAutor(), l.getIsbn());
        }
    }

    private void modificar() {
        System.out.println("\n--- MODIFICAR LIBRO ---");
        System.out.print("Ingrese el ID del libro a modificar: ");
        int id = Integer.parseInt(scanner.nextLine());
        
        Libro editado = new Libro();
        editado.setId(id);
        System.out.print("Nuevo Título: ");
        editado.setTitulo(scanner.nextLine());
        System.out.print("Nuevo Autor: ");
        editado.setAutor(scanner.nextLine());
        System.out.print("Nuevo ISBN: ");
        editado.setIsbn(scanner.nextLine());
        
        if (dao.modificar(editado)) {
            System.out.println("¡Libro actualizado correctamente!");
        } else {
            System.out.println("No se encontró ningún libro con el ID especificado.");
        }
    }

    private void eliminar() {
        System.out.println("\n--- ELIMINAR LIBRO ---");
        System.out.print("Ingrese el ID del libro a eliminar: ");
        int id = Integer.parseInt(scanner.nextLine());
        
        if (dao.eliminar(id)) {
            System.out.println("¡Libro eliminado correctamente!");
        } else {
            System.out.println("No se encontró ningún libro con el ID especificado.");
        }
    }
}